﻿using Android.App;
using XXYXX.Mobile.AppCore;
using Supermodel.Mobile.Runtime.Droid.App;

namespace XXYXX.Mobile.Droid
{
    [Activity(Label = "XXYXX.Droid", MainLauncher = true)]
    public class MainActivity : DroidFormsApplication<XXYXXApp> { }
}

