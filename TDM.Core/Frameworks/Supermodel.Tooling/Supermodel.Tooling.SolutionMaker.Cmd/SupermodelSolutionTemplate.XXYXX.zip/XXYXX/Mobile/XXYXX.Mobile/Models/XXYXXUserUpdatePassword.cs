﻿#nullable enable

// ReSharper disable once CheckNamespace
namespace Supermodel.ApiClient.Models
{
    public partial class XXYXXUserUpdatePassword
    {
        //put your additional stuff here, if you need it
    }
}
