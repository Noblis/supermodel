﻿using Foundation;
using Supermodel.Mobile.Runtime.iOS.App;
using XXYXX.Mobile.AppCore;

namespace XXYXX.Mobile.iOS
{
    [Register("AppDelegate")]
    public class AppDelegate : iOSFormsApplication<XXYXXApp> { }
}