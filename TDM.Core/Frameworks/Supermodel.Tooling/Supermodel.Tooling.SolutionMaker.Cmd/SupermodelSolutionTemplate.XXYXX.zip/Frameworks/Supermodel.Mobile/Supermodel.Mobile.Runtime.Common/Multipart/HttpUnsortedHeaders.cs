
namespace Supermodel.Mobile.Runtime.Common.Multipart
{
    using System.Net.Http.Headers;
    
    public class HttpUnsortedHeaders : HttpHeaders {}
}