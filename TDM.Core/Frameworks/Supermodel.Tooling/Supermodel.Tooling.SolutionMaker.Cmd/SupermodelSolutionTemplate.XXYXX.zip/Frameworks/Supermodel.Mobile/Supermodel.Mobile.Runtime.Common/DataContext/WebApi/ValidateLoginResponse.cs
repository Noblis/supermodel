﻿namespace Supermodel.Mobile.Runtime.Common.DataContext.WebApi
{
    public class ValidateLoginResponse
    {
        public long? UserId { get; set; }
        public string UserLabel { get; set; }
    }
}
