﻿namespace Supermodel.Mobile.Runtime.Common.Services
{
    public interface IAudioService
    {
        void Play(byte[] wavSound);
        
        //void StartRecording();
        //byte[] StopRecording();
    }
}