﻿namespace Supermodel.Mobile.Runtime.Common.Models
{
    public class BinaryFile
	{
		public string FileName { get; set; }
		public byte[] BinaryContent { get; set; }
	}
}
