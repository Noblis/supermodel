﻿namespace Supermodel.Mobile.Runtime.Common.Services
{
    public enum Platform { IOS, Droid, DotNetCore }
}