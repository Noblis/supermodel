﻿namespace Supermodel.Mobile.Runtime.Common.Models
{
    public interface IHaveIdentity
    {
        string Identity { get; }
    }
}
