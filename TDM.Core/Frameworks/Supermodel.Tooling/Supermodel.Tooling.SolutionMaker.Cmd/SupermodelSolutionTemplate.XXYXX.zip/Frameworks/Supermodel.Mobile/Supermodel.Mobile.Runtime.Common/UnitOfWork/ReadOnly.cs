﻿namespace Supermodel.Mobile.Runtime.Common.UnitOfWork
{
    public enum ReadOnly
    {
        No,
        Yes,
    }
}