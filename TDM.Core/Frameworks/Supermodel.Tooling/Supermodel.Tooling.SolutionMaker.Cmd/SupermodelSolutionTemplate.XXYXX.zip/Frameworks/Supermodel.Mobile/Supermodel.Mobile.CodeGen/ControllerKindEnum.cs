﻿#nullable enable

namespace Supermodel.Mobile.CodeGen
{
    public enum ControllerKindEnum
    {
        CRUD, EnhancedCRUD, Command,
        WMCRUD, WMEnhancedCRUD, WMCommand
    }
}