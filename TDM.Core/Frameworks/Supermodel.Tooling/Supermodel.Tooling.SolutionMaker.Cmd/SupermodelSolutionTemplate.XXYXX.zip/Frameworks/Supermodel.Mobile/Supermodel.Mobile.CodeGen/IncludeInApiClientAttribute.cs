﻿#nullable enable

using System;

namespace Supermodel.Mobile.CodeGen
{
    public class IncludeInApiClientAttribute : Attribute{}
}
