﻿#nullable enable

using System.ComponentModel;

namespace Supermodel.Tooling.SolutionMaker
{
    public enum WebFrameworkEnum 
    { 
        [Description("WebMonk")] WebMonk, 
        [Description("MVC")] Mvc
    }
}