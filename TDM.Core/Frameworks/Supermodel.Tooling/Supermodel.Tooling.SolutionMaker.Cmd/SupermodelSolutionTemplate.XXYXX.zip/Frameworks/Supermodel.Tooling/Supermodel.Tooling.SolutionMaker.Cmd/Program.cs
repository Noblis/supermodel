﻿using System;

namespace Supermodel.Tooling.SolutionMaker.Cmd
{
    class Program
    {
        // ReSharper disable once UnusedParameter.Local
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
