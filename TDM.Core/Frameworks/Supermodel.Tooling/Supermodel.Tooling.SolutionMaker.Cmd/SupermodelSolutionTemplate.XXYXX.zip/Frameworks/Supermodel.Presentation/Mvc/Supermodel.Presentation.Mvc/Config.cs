﻿#nullable enable

namespace Supermodel.Presentation.Mvc
{
    public static class Config
    {
        public static string InlinePrefix { get; set; } = "smInline";
        public static string ModelState { get; set; } = "ModelState";
    }
}
