﻿#nullable enable

namespace Supermodel.Persistence.UnitOfWork
{
    public enum MustBeWritable
    {
        No,
        Yes,
    }
}