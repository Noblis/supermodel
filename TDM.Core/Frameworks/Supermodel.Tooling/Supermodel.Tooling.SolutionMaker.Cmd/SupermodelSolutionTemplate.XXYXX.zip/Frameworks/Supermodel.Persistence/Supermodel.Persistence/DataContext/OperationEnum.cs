﻿#nullable enable

namespace Supermodel.Persistence.DataContext
{
    public enum OperationEnum { Add, Delete, Update }
}