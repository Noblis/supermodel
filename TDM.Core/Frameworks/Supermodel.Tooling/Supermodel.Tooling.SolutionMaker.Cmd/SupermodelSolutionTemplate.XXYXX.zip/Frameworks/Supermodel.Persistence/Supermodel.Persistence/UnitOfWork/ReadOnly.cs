﻿#nullable enable

namespace Supermodel.Persistence.UnitOfWork
{
    public enum ReadOnly
    {
        No,
        Yes,
    }
}