﻿#nullable enable

namespace WebMonk.ValueProviders
{
    public class RouteValueProvider : ValueProvider { }
}