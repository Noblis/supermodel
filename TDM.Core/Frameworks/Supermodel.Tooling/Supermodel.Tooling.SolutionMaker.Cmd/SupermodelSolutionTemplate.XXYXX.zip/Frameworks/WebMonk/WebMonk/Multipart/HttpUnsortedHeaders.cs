
using System.Net.Http.Headers;

namespace WebMonk.Multipart
{
    public class HttpUnsortedHeaders : HttpHeaders {}
}