﻿#nullable enable

namespace WebMonk.Exceptions
{
    public class Exception404PageNotFound : WebMonkException {}
}
