﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Rt : Tag
    {
        #region Constructors
        public Rt(object? attributes = null) : base("rt", attributes) { }
        #endregion
    }
}
