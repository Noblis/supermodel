﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Ul : Tag
    {
        #region Constructors
        public Ul(object? attributes = null) : base("ul", attributes) { }
        #endregion
    }
}
