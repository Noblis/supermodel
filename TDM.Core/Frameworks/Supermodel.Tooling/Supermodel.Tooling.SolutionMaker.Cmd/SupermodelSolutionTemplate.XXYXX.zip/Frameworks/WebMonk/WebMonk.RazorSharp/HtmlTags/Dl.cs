﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Dl : Tag
    {
        #region Constructors
        public Dl(object? attributes = null) : base("dl", attributes) { }
        #endregion
    }
}
