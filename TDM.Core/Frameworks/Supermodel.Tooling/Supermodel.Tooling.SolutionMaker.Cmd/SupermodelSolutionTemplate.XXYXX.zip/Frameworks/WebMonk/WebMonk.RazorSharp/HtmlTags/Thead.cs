﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Thead : Tag
    {
        #region Constructors
        public Thead(object? attributes = null) : base("thead", attributes) { }
        #endregion
    }
}
