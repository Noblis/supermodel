﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Main : Tag
    {
        #region Constructors
        public Main(object? attributes = null) : base("main", attributes) { }
        #endregion
    }
}
