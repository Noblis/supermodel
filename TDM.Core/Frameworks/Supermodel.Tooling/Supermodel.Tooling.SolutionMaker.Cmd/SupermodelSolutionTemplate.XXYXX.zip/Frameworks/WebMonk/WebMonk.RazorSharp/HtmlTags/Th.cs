﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Th : Tag
    {
        #region Constructors
        public Th(object? attributes = null) : base("th", attributes) { }
        #endregion
    }
}
