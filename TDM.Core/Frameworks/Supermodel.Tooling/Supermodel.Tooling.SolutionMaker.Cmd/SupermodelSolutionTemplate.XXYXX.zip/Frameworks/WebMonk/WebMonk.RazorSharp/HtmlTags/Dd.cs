﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Dd : Tag
    {
        #region Constructors
        public Dd(object? attributes = null) : base("dd", attributes) { }
        #endregion
    }
}
