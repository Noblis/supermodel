﻿//#nullable enable

//using System.Collections.Generic;
//using WebMonk.RazorSharp.Tags.BaseTags;

//namespace WebMonk.RazorSharp.Extensions
//{
//    public static class IEnumerableTagsExt
//    {
//        public static IGenerateHtml ToIGenerateHtml(this IEnumerable<Tag> me)
//        {
//            var tags = new Tags.BaseTags.Tags();
//            tags.AddRange(me);
//            return tags;
//        }
//    }
//}
