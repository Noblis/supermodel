﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Dt : Tag
    {
        #region Constructors
        public Dt(object? attributes = null) : base("dt", attributes) { }
        #endregion
    }
}
