﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class U : Tag
    {
        #region Constructors
        public U(object? attributes = null) : base("u", attributes) { }
        #endregion
    }
}
