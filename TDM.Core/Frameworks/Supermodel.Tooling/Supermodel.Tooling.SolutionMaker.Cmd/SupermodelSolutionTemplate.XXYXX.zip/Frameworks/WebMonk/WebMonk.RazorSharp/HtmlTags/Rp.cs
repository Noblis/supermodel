﻿#nullable enable

using WebMonk.RazorSharp.HtmlTags.BaseTags;

namespace WebMonk.RazorSharp.HtmlTags
{
    public class Rp : Tag
    {
        #region Constructors
        public Rp(object? attributes = null) : base("rp", attributes) { }
        #endregion
    }
}
