﻿#nullable enable

namespace Supermodel.DataAnnotations.Enums
{
    public enum ValidationSummaryVisible
    {
        Always, Never, IfNoVisibleErrors
    }
}
