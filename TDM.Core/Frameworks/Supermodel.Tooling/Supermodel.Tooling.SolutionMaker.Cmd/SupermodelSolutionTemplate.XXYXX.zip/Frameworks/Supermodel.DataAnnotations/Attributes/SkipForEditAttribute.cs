﻿#nullable enable

using System;

namespace Supermodel.DataAnnotations.Attributes
{
    public class SkipForEditAttribute : Attribute { }
}
