﻿using System;

namespace Supermodel.DataAnnotations.Attributes
{
    public class SkipForDisplayAttribute : Attribute { }
}