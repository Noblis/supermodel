﻿#nullable enable

namespace Supermodel.DataAnnotations.Attributes
{
    public interface IUIComponentWithValue
    {
        string ComponentValue { get; set; }
    }
}
