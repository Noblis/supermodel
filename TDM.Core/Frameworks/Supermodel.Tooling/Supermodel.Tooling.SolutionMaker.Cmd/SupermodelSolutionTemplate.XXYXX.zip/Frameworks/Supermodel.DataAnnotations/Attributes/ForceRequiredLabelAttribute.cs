﻿#nullable enable

using System;

namespace Supermodel.DataAnnotations.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class ForceRequiredLabelAttribute : Attribute { }
}