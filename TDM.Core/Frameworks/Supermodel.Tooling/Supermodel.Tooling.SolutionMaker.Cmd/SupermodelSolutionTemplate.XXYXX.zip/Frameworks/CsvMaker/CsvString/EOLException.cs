﻿#nullable enable

using System;

namespace CsvMaker.CsvString
{
    public class EOLException : Exception { }
}
