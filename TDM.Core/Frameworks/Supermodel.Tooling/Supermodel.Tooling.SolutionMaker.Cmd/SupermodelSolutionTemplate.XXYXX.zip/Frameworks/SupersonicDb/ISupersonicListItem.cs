﻿using System;

namespace Supersonic
{
    public interface ISupersonicListItem
    {
        Guid Guid { get; }
    }
}
